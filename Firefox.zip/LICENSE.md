© Armen-Jean Andreasian 2024. All rights reserved.

This software is proprietary. Unauthorized:
- Distribution
- Modification
- Commercial use
