// blocked.js
document.getElementById("backButton").addEventListener("click", () => {
    window.history.back();
});