My new solo-developer's project: DeepFocus


No willpower needed.

No motivational speechs.


FocusGuard is a browser extension that blocks distracting websites and helps you stay focused once you study or work.


Step 1. List your time-wasting sites

Step 2: Flip the switch

Step 3: Try to procrastinate → See a beautiful synth-wave banner reminding to get back to work.


Entire extension is done in beautiful synth-wave styling.


Privacy Policy.


Zero data collection:

- No personal information

- No tracking/analytics

- No external data storage


- 100% local operations

-



#NoExcuses #FocusOrFail #SoloDev #SoftwareDevelopment


# Privacy Policy for DeepFocus

## Data Collection
Zero data collection:
- No personal information
- No tracking/analytics
- No external data storage

## Payments
- Supporter features use third-party processors (Stripe/Paddle)
- Extension never handles payment data
- Transactions governed by processor's policies

## Technical
- 100% local operation
- Mozilla servers for updates only
- Closed-source proprietary software
- Browser-level implementation, which means the websites are not actually blocked, you just get redirected to a custom banner. Whenever, you turn off the extension, you are free to use them. No DNS or reverse proxies. I think this is important for most of non-tech people.


## Legal
© Armen-Jean Andreasian 2024. All rights reserved.
Violations will be prosecuted.